

```python
# Dependencies
import os
import csv
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

```


```python
# The path to CSV file
city = "city_data.csv"
ride = "ride_data.csv"

# Read data into pandas
city_df = pd.read_csv(city)
ride_df = pd.read_csv(ride)
```


```python
city_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Nguyenbury</td>
      <td>8</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>2</th>
      <td>East Douglas</td>
      <td>12</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>3</th>
      <td>West Dawnfurt</td>
      <td>34</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Rodriguezburgh</td>
      <td>52</td>
      <td>Urban</td>
    </tr>
  </tbody>
</table>
</div>




```python
ride_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Sarabury</td>
      <td>2016-01-16 13:49:27</td>
      <td>38.35</td>
      <td>5403689035038</td>
    </tr>
    <tr>
      <th>1</th>
      <td>South Roy</td>
      <td>2016-01-02 18:42:34</td>
      <td>17.49</td>
      <td>4036272335942</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Wiseborough</td>
      <td>2016-01-21 17:35:29</td>
      <td>44.18</td>
      <td>3645042422587</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Spencertown</td>
      <td>2016-07-31 14:53:22</td>
      <td>6.87</td>
      <td>2242596575892</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Nguyenbury</td>
      <td>2016-07-09 04:42:44</td>
      <td>6.28</td>
      <td>1543057793673</td>
    </tr>
  </tbody>
</table>
</div>




```python
merged_data = pd.merge(ride_df, city_df, how = 'left', on = ['city', 'city'])
merged_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
      <th>driver_count</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Sarabury</td>
      <td>2016-01-16 13:49:27</td>
      <td>38.35</td>
      <td>5403689035038</td>
      <td>46</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>1</th>
      <td>South Roy</td>
      <td>2016-01-02 18:42:34</td>
      <td>17.49</td>
      <td>4036272335942</td>
      <td>35</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Wiseborough</td>
      <td>2016-01-21 17:35:29</td>
      <td>44.18</td>
      <td>3645042422587</td>
      <td>55</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Spencertown</td>
      <td>2016-07-31 14:53:22</td>
      <td>6.87</td>
      <td>2242596575892</td>
      <td>68</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Nguyenbury</td>
      <td>2016-07-09 04:42:44</td>
      <td>6.28</td>
      <td>1543057793673</td>
      <td>8</td>
      <td>Urban</td>
    </tr>
  </tbody>
</table>
</div>



Bubble Chart Data


```python
# City Type (colors)
Urban = merged_data[merged_data["type"] == "Urban"]
Suburban = merged_data[merged_data["type"] == "Suburban"]
Rural = merged_data[merged_data["type"] == "Rural"]
```


```python
# Total Number of Rides per City (x_axis)
Urban_rides = Urban.groupby(["city"]).count()["ride_id"]
Suburban_rides = Suburban.groupby(["city"]).count()["ride_id"]
Rural_rides = Rural.groupby(["city"]).count()["ride_id"]
```


```python
# Average Fare per City (y_axis)
Urban_fares= Urban.groupby(["city"]).mean()["fare"]
Suburban_fares = Suburban.groupby(["city"]).mean()["fare"]
Rural_fares = Rural.groupby(["city"]).mean()["fare"]
```


```python
# Total Number of Drivers per City (size of bubble)
Urban_drivers = Urban.groupby(["city"]).count()["driver_count"]
Suburban_drivers = Suburban.groupby(["city"]).count()["driver_count"]
Rural_drivers = Rural.groupby(["city"]).count()["driver_count"]
```


```python
# Bubble chart
plt.scatter(Urban_rides, Urban_fares, s=Urban_drivers*10, marker ='o', facecolors ="lightcoral", edgecolors='black',alpha = 0.5, label="Urban")
plt.scatter(Suburban_rides, Suburban_fares, s=Suburban_drivers*10, marker ='o', facecolors ="lightblue", edgecolors='black',alpha = 0.5, label="Suburban")
plt.scatter(Rural_rides, Rural_fares, s=Rural_drivers*10, marker ='o', facecolors ="gold", edgecolors='black',alpha = 0.5, label="Rural")

# Chart title
plt.title("Pyber Ride Sharing Data (2016)")
# x label
plt.xlabel("Total Numbers of Rides (Per City))")
# y label
plt.ylabel("Average Fare($)")
# legend 
plt.legend(loc='upper right', fontsize=10)
```




    <matplotlib.legend.Legend at 0x1eea6a9dd68>




![png](output_10_1.png)


Note: Circle size correlates with driver count per city.


```python
# Total Fare by City Type
total_fare = merged_data.groupby(['type'])['fare'].sum()
# Labels for pie chart
labels = ["Rural","Suburban","Urban" ]
# Colors for the pie chart
colors = ["gold","lightskyblue","lightcoral"]
explode = (0, 0, 0.1)
plt.title("% of Total Fares By City Types")
plt.pie(total_fare, explode=explode, labels=labels, colors=colors, autopct="%1.1f%%",shadow=True, startangle=100)
plt.axis("equal")
plt.show()
```


![png](output_12_0.png)



```python
# Total Rides by City Type
total_rides = merged_data.groupby(['type'])['ride_id'].count()
# Labels for pie chart
labels = ["Rural","Suburban","Urban" ]
# Colors for pie chart
colors = ["gold","lightskyblue","lightcoral"]
explode = (0, 0, 0.1)
plt.title("% of Total Rides By City Types")
plt.pie(total_rides, explode=explode, labels=labels, colors=colors,
        autopct="%1.1f%%", shadow=True, startangle=100)
plt.axis("equal")
plt.show()
```


![png](output_13_0.png)



```python
# Total Drivers by City Type
total_drivers = merged_data.groupby(['type'])['driver_count'].sum()
# Labels for pie chart
labels = ["Rural","Suburban","Urban" ]
# Colors of each section of the pie chart
colors = ["gold","lightskyblue","lightcoral"]
explode = (0, 0, 0.1)
plt.title("% of Total Drivers By City Types")
plt.pie(total_drivers, explode=explode, labels=labels, colors=colors,
        autopct="%1.1f%%", shadow=True, startangle=100)
plt.axis("equal")
plt.show()
```


![png](output_14_0.png)


Observations:

1) Rural cities had the lowest "Total Number of Rides", but had the highest "Average fare".

2) The "Average fare" was approximately $5-10 more in the Suburban cities than Rural cities.

3) Urban cities had the highest "% of Tota Fares", "% of Total Rides", and "% of Total Drivers". 
